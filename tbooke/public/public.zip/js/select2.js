$(document).ready(function() {
    $('.favorite-topics').select2({placeholder: "Select your favorite topics"});
    });
    
    $(document).ready(function() {
        $('.subjects').select2({placeholder: "Select your subjects"});
        });
        

        